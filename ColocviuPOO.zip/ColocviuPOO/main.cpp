﻿#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

// Clasa de bază pentru entități comune
// Clasa de bază pentru entitățile comune (Angajat, Produs, Comanda, Eveniment)
// Concept OOP: **Moștenire** - clasele derivate (Angajat, Produs, etc.) vor moșteni din această clasă de bază
class Entitate {
    // Funcție virtuală pentru afișarea informațiilor despre entitate
    // Concept OOP: **Polimorfism** - Funcția virtuală poate fi suprascrisă în clasele derivate pentru a avea implementări specifice
public:
    virtual void afisareInfo() const = 0;
    virtual string getNume() const = 0;
    virtual ~Entitate() {}// Destructor virtual pentru a permite eliberarea corectă a memoriei atunci când este folosit un pointer la entitate
    // Funcție virtuală pentru obținerea numelui entității
    // Concept OOP: **Polimorfism** - Se poate modifica comportamentul acestei funcții în clasele derivate
};

// Clasa pentru angajați
class Angajat : public Entitate {
private:
    string nume;// Numele angajatului
    string functie; // Funcția angajatului
    string oraInceput; // Ora de început a programului
    string oraSfarsit; // Ora de sfârșit a programului
    string oras; // Orașul unde lucrează angajatul
     // Constructor pentru crearea unui angajat
    // Concept OOP: **Constructor** - Inițializează un obiect Angajat cu datele specifice
    // Suprascrierea funcției afisareInfo() pentru afișarea detaliilor unui angajat
    // Concept OOP: **Polimorfism** - Funcția este suprascrisă în clasa derivată pentru a afișa informații specifice despre angajat
    // Suprascrierea funcției getNume() pentru a returna numele angajatului
    // Concept OOP: **Polimorfism** - Funcția este specifică fiecărui tip de entitate
    // Convertește un obiect Angajat într-un format CSV
    // Concept OOP: **Abstracție** - Extrage informațiile relevante ale obiectului într-un format simplu
     // Creează un obiect Angajat dintr-un string CSV
    // Concept OOP: **Abstracție** - Împachetează informațiile într-un format simplu pentru crearea obiectului
    
public:
    Angajat(string nume, string functie, string oraInceput, string oraSfarsit, string oras)
        : nume(nume), functie(functie), oraInceput(oraInceput), oraSfarsit(oraSfarsit), oras(oras) {}

    void afisareInfo() const override {
        cout << "Angajat: " << nume << ", Functie: " << functie << ", Ora inceput: " << oraInceput
             << ", Ora sfarsit: " << oraSfarsit << ", Oras: " << oras << endl;
    }

    string getNume() const override {
        return nume;
    }

    string toCSV() const {
        return nume + "," + functie + "," + oraInceput + "," + oraSfarsit + "," + oras;
    }

    static Angajat fromCSV(const string& csvLine) {
        stringstream ss(csvLine);
        string nume, functie, oraInceput, oraSfarsit, oras;
        getline(ss, nume, ',');
        getline(ss, functie, ',');
        getline(ss, oraInceput, ',');
        getline(ss, oraSfarsit, ',');
        getline(ss, oras, ',');
        return Angajat(nume, functie, oraInceput, oraSfarsit, oras);
    }
};

// Clasa pentru produse
// Concept OOP: **Moștenire** - Clasa Produs moștenește din clasa Entitate

class Produs : public Entitate {
private:
    string nume; // Numele produsului
    string categorie; // Categoria produsului
    double pret;  // Prețul produsului
    int stocBucuresti;// Stocuri pentru diferite orașe
    int stocCluj;
    int stocTimisoara;
    int stocIasi;
    int stocBrasov;
    // Constructor pentru crearea unui produs
    // Concept OOP: **Constructor** - Permite inițializarea unui obiect Produs cu datele sale
    // Suprascrierea funcției afisareInfo() pentru afișarea detaliilor unui produs
    // Concept OOP: **Polimorfism** - Funcția este suprascrisă pentru a afișa informații specifice despre produs
    // Suprascrierea funcției getNume() pentru a returna numele produsului
    // Concept OOP: **Polimorfism** - Funcția se adaptează pentru produs
    // Modifică stocul produsului pentru un anumit oraș
    // Concept OOP: **Encapsulare** - Manipularea stocurilor este controlată printr-o funcție specială
    // Creează un obiect Produs dintr-un string CSV
    // Concept OOP: **Abstracție** - Permite crearea unui obiect Produs dintr-un text simplu
public:
    Produs(string nume, string categorie, double pret, int stocBucuresti, int stocCluj,
           int stocTimisoara, int stocIasi, int stocBrasov)
        : nume(nume), categorie(categorie), pret(pret), stocBucuresti(stocBucuresti), stocCluj(stocCluj),
          stocTimisoara(stocTimisoara), stocIasi(stocIasi), stocBrasov(stocBrasov) {}

    void afisareInfo() const override {
        cout << "Produs: " << nume << ", Categorie: " << categorie << ", Pret: " << pret << " RON"
             << ", Stoc Bucuresti: " << stocBucuresti << ", Stoc Cluj: " << stocCluj
             << ", Stoc Timisoara: " << stocTimisoara << ", Stoc Iasi: " << stocIasi
             << ", Stoc Brasov: " << stocBrasov << endl;
    }

    string getNume() const override {
        return nume;
    }

    void modificaStoc(int stocNou, const string& oras) {
        if (oras == "Bucuresti") stocBucuresti = stocNou;
        else if (oras == "Cluj") stocCluj = stocNou;
        else if (oras == "Timisoara") stocTimisoara = stocNou;
        else if (oras == "Iasi") stocIasi = stocNou;
        else if (oras == "Brasov") stocBrasov = stocNou;
    }

    string toCSV() const {
        return nume + "," + categorie + "," + to_string(pret) + "," + to_string(stocBucuresti) + ","
               + to_string(stocCluj) + "," + to_string(stocTimisoara) + "," + to_string(stocIasi) + ","
               + to_string(stocBrasov);
    }

    static Produs fromCSV(const string& csvLine) {
        stringstream ss(csvLine);
        string nume, categorie;
        double pret;
        int stocBucuresti, stocCluj, stocTimisoara, stocIasi, stocBrasov;

        getline(ss, nume, ',');
        getline(ss, categorie, ',');
        ss >> pret;
        ss.ignore(1, ',');
        ss >> stocBucuresti;
        ss.ignore(1, ',');
        ss >> stocCluj;
        ss.ignore(1, ',');
        ss >> stocTimisoara;
        ss.ignore(1, ',');
        ss >> stocIasi;
        ss.ignore(1, ',');
        ss >> stocBrasov;

        return Produs(nume, categorie, pret, stocBucuresti, stocCluj, stocTimisoara, stocIasi, stocBrasov);
    }
};

// Clasa pentru comenzi
class Comanda : public Entitate {
private:
    string idComanda;
    string numeClient;
    string data;
    double valoare;

public:
    Comanda(string idComanda, string numeClient, string data, double valoare)
        : idComanda(idComanda), numeClient(numeClient), data(data), valoare(valoare) {}

    void afisareInfo() const override {
        cout << "Comanda: " << idComanda << ", Client: " << numeClient << ", Data: " << data
            << ", Valoare: " << valoare << " RON" << endl;
    }

    string getNume() const override {
        return idComanda;
    }

    string toCSV() const {
        return idComanda + "," + numeClient + "," + data + "," + to_string(valoare);
    }

    static Comanda fromCSV(const string& csvLine) {
        stringstream ss(csvLine);
        string idComanda, numeClient, data;
        double valoare;

        getline(ss, idComanda, ',');
        getline(ss, numeClient, ',');
        getline(ss, data, ',');
        ss >> valoare;

        return Comanda(idComanda, numeClient, data, valoare);
    }
};

// Clasa pentru evenimente
class Eveniment : public Entitate {
private:
    string numeEveniment;
    string locatie;
    string data;
    string ora;

public:
    Eveniment(string numeEveniment, string locatie, string data, string ora)
        : numeEveniment(numeEveniment), locatie(locatie), data(data), ora(ora) {}

    void afisareInfo() const override {
        cout << "Eveniment: " << numeEveniment << ", Locatie: " << locatie
            << ", Data: " << data << ", Ora: " << ora << endl;
    }

    string getNume() const override {
        return numeEveniment;
    }

    string toCSV() const {
        return numeEveniment + "," + locatie + "," + data + "," + ora;
    }

    static Eveniment fromCSV(const string& csvLine) {
        stringstream ss(csvLine);
        string numeEveniment, locatie, data, ora;

        getline(ss, numeEveniment, ',');
        getline(ss, locatie, ',');
        getline(ss, data, ',');
        getline(ss, ora, ',');

        return Eveniment(numeEveniment, locatie, data, ora);
    }
};
// Funcții pentru citirea și scrierea în fișiere CSV
void citesteDinCSV(const string& fisier, vector<Angajat*>& angajati) {
    ifstream infile(fisier);
    string line;

    while (getline(infile, line)) {
        angajati.push_back(new Angajat(Angajat::fromCSV(line)));
    }
}

void citesteDinCSV(const string& fisier, vector<Produs*>& produse) {
    ifstream infile(fisier);
    string line;

    while (getline(infile, line)) {
        produse.push_back(new Produs(Produs::fromCSV(line)));
    }
}

void citesteDinCSV(const string& fisier, vector<Comanda*>& comenzi) {
    ifstream infile(fisier);
    string line;

    while (getline(infile, line)) {
        comenzi.push_back(new Comanda(Comanda::fromCSV(line)));
    }
}

void citesteDinCSV(const string& fisier, vector<Eveniment*>& evenimente) {
    ifstream infile(fisier);
    string line;

    while (getline(infile, line)) {
        evenimente.push_back(new Eveniment(Eveniment::fromCSV(line)));
    }
}

void scrieInCSV(const string& fisier, const vector<Entitate*>& entitati) {
    ofstream outfile(fisier);
    if (!outfile.is_open()) {
        cerr << "Eroare la deschiderea fisierului " << fisier << " pentru scriere." << endl;
        return;
    }

    for (const auto& entitate : entitati) {
        if (auto angajat = dynamic_cast<Angajat*>(entitate)) {
            outfile << angajat->toCSV() << endl;
        } else if (auto produs = dynamic_cast<Produs*>(entitate)) {
            outfile << produs->toCSV() << endl;
        } else if (auto comanda = dynamic_cast<Comanda*>(entitate)) {
            outfile << comanda->toCSV() << endl;
        } else if (auto eveniment = dynamic_cast<Eveniment*>(entitate)) {
            outfile << eveniment->toCSV() << endl;
        }
    }
}

template <typename T>
void cautaEntitate(const vector<T*>& entitati, const string& nume) {
    bool gasit = false;
    for (const auto& entitate : entitati) {
        if (entitate->getNume() == nume) {
            entitate->afisareInfo();
            gasit = true;
            break;
        }
    }
    if (!gasit) {
        cout << "Entitatea cu numele " << nume << " nu a fost gasita.\n";
    }
}

template <typename T>
void stergeEntitate(vector<T*>& entitati, const string& nume) {
    auto it = remove_if(entitati.begin(), entitati.end(), [&](T* entitate) {
        return entitate->getNume() == nume;
    });

    if (it != entitati.end()) {
        delete *it;
        entitati.erase(it);
        cout << "Entitatea cu numele " << nume << " a fost stearsa.\n";
    } else {
        cout << "Nu s-a gasit entitatea pentru a fi stearsa.\n";
    }
}

int main() {
    vector<Angajat*> angajati;
    vector<Produs*> produse;
    vector<Comanda*> comenzi;
    vector<Eveniment*> evenimente;

    citesteDinCSV("angajati.csv", angajati);
    citesteDinCSV("produse.csv", produse);
    citesteDinCSV("comenzi.csv", comenzi);
    citesteDinCSV("evenimente.csv", evenimente);

    while (true) {
        cout << "1. Cauta angajat\n2. Cauta produs\n3. Adauga angajat\n4. Adauga produs\n5. Sterge angajat\n6. Sterge produs\n";
        cout << "7. Cauta comanda\n8. Cauta eveniment\n9. Adauga comanda\n10. Adauga eveniment\n";
        cout << "11. Sterge comanda\n12. Sterge eveniment\n13. Iesire\n";
        int optiune;
        cout << "Alegeti o optiune: ";
        cin >> optiune;
        cin.ignore();

        if (optiune == 7) {
            string idComanda;
            cout << "Introduceti ID-ul comenzii de cautat: ";
            getline(cin, idComanda);
            cautaEntitate(comenzi, idComanda);
        } else if (optiune == 8) {
            string numeEveniment;
            cout << "Introduceti numele evenimentului de cautat: ";
            getline(cin, numeEveniment);
            cautaEntitate(evenimente, numeEveniment);
        } else if (optiune == 9) {
            // Adauga o comanda
            string idComanda, numeClient, data;
            double valoare;
            cout << "Introduceti detaliile comenzii (ID, nume client, data, valoare): ";
            getline(cin, idComanda);
            getline(cin, numeClient);
            getline(cin, data);
            cin >> valoare;
            comenzi.push_back(new Comanda(idComanda, numeClient, data, valoare));
        } else if (optiune == 10) {
            // Adauga un eveniment
            string numeEveniment, locatie, data, ora;
            cout << "Introduceti detaliile evenimentului (nume, locatie, data, ora): ";
            getline(cin, numeEveniment);
            getline(cin, locatie);
            getline(cin, data);
            getline(cin, ora);
            evenimente.push_back(new Eveniment(numeEveniment, locatie, data, ora));
        } else if (optiune == 11) {
            string idComanda;
            cout << "Introduceti ID-ul comenzii de sters: ";
            getline(cin, idComanda);
            stergeEntitate(comenzi, idComanda);
        } else if (optiune == 12) {
            string numeEveniment;
            cout << "Introduceti numele evenimentului de sters: ";
            getline(cin, numeEveniment);
            stergeEntitate(evenimente, numeEveniment);
        } else if (optiune == 13) {
            break;
        } else {
            cout << "Optiune invalida!\n";
        }
    }

    // Scrierea datelor înapoi în fișiere
    vector<Entitate*> entitatiAngajati(angajati.begin(), angajati.end());
    vector<Entitate*> entitatiProduse(produse.begin(), produse.end());
    vector<Entitate*> entitatiComenzi(comenzi.begin(), comenzi.end());
    vector<Entitate*> entitatiEvenimente(evenimente.begin(), evenimente.end());

    scrieInCSV("angajati.csv", entitatiAngajati);
    scrieInCSV("produse.csv", entitatiProduse);
    scrieInCSV("comenzi.csv", entitatiComenzi);
    scrieInCSV("evenimente.csv", entitatiEvenimente);

    // Eliberarea memoriei
    for (auto& angajat : angajati) delete angajat;
    for (auto& produs : produse) delete produs;
    for (auto& comanda : comenzi) delete comanda;
    for (auto& eveniment : evenimente) delete eveniment;

    return 0;
}